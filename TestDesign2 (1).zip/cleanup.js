const path = require("path");
const rimraf = require("rimraf");
const { run } = require("./apilogics/apimatrix");

const cleanUp = () => {
   let absPath = "../";
   let runFolder = path.join(absPath,"_RUNS")
   console.log(runFolder, " runFolder ")
   rimraf.sync(runFolder);
   console.log("Deleted Folder")
}
cleanUp();