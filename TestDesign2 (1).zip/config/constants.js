exports.constants = {
    "hexConversion": true
}