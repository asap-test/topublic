const Excel = require("exceljs");
const async = require("async");
const path = require("path");
const fs = require("fs")
const fse = require("fs-extra");
const _ = require("lodash");
const formatXml = require("xml-formatter");
const transacTemplate = path.join("utils", "trans_matrix_template.xml");


// Creating XML for ACT Tool using the data from XL file
exports.crtXML = (paths, sheetName, hexFlag, errTxt) => {
   let workbook = new Excel.Workbook();
   let productNames = [];
   let attrNames = [];
   let uniqAttr;
   let {
      sourcePath,
      results,
      transMat
   } = paths;
   let errorProducts = [];
   let attrNoError = true;
   // console.log(paths, " paths  ")
   // console.log(sheetName, " sheetName ")

   return new Promise((resolve, reject) => {
      async.waterfall([
         copyXL,
         getRowNos,
         getRawXLData,
         applyTestMthdlogy,
         applyNegOptimizn,
         constraintData,
         writeXML,
         crtProductFlName,
         crtAttrbtFlName
      ], (err) => {
         if (err) {
            attrNoError === false ? resolve(false) : reject(err)
         } else {
            let bool = true;
            if (errorProducts.length > 0 && attrNoError === false) {
               bool = false;
               let errorProd = ``;
               let uniqErrProd = _.uniq(errorProducts)
               uniqErrProd.map((val, index) => {
                  let value = val && `${val.charAt(0).toUpperCase()}${val.substring(1)}`;
                  errorProd += `${index+1})${value}\n`
               });
               errTxt.push(`In ${sheetName} Transaction the below attributes should have atleast one positive value for each product.Please update the product mapping and upload again.\n${errorProd}\n`)
            }
            resolve(bool)
         }
      })
   })

   // Creating the copy of the Source XL File
   function copyXL(callBack) {
      if (fs.existsSync(sourcePath)) {
         if (fs.existsSync(results)) {
            let src = path.join(sourcePath, `source.xlsx`);
            let dest = path.join(results, `results.xlsx`);
            try {
               if (!fs.existsSync(dest)) {
                  fse.copySync(src, dest)
               }
               callBack(null, dest)
            } catch (err) {
               callBack(new Error("Error in copying the source file"))
            }
         } else {
            callBack(new Error("Error in copying the source file"))
         }
      } else {
         callBack(new Error("Source Path Doesn't Exist"))
      }
   }

   // Getting the Row Numbers , prodStart Index &  prodLast Index based on tags
   function getRowNos(filename, callBack) {
      let tranTags = {};
      workbook.xlsx.readFile(filename)
         .then(() => {
            let ws = workbook.getWorksheet(sheetName)
            ws.eachRow((row, rowNumber) => {
               row.eachCell((cell) => {
                  if (cell.value === "#at-start") {
                     // tranTags.mergeCells = Object.keys(row["_worksheet"]["_merges"]);
                     tranTags.firstRowNo = rowNumber;
                     tranTags.actualRwCount = ws.actualRowCount;
                     tranTags.actualColmnCount = ws.actualColumnCount;
                     tranTags.attrIndx = row.values.indexOf("#at-start");
                     tranTags.valuesIndx = row.values.indexOf("#values");
                     tranTags.prodStart = row.values.indexOf("#prod-start");
                     tranTags.prodLast = row.values.indexOf("#prod-end");
                  } else if (cell.value === "Test Methodology") {
                     tranTags.testMthdIndx = row.values.indexOf(cell.value);
                     tranTags.prodRowNo = rowNumber;
                  } else if (cell.value === "#at-end") {
                     tranTags.lastRowNo = rowNumber;
                  } else if (cell.value === "#constraint-product-start") {
                     tranTags.conStrtRow = rowNumber;
                     tranTags.conProdIndx = row.values.indexOf("#constraint-product-start");
                     tranTags.conAttrIndx = row.values.indexOf("#constraint-attr");
                     tranTags.conValIndx = row.values.indexOf("#constraint-value");
                     tranTags.conDepAttrIndx = row.values.indexOf("#dep-atr");
                     tranTags.conOperatorIndx = row.values.indexOf("#operator");
                     tranTags.depValStrtIndx = row.values.indexOf("#dep-val-start");
                     tranTags.depValEndIndx = row.values.indexOf("#dep-val-end");
                  } else if (cell.value === "#constraint-product-end") {
                     tranTags.conEndRow = rowNumber;
                  } else if (cell.value === "#txn-start") {
                     tranTags.endRow = rowNumber;
                  }
               })
            })
            callBack(null, tranTags, ws, filename);
         })
         .catch((error) => {
            callBack(error)
         })
   }

   // Getting the Raw XL Data from the copied XL File and finding the missed indexes in products
   function getRawXLData(tranTags, ws, filename, callBack) {
      let {
         attrIndx,
         valuesIndx,
         prodStart,
         prodLast,
         prodRowNo,
         lastRowNo,
         testMthdIndx,
         conStrtRow,
         conEndRow
      } = tranTags;
      let pickIndex = [attrIndx, valuesIndx, testMthdIndx, prodStart, prodLast]
      let missingIndex = [];
      for (let i = prodStart + 1; i < prodLast; i++) {
         missingIndex.push(i);
      }
      pickIndex.splice(4, 0, ...missingIndex);
      let records = [];
      let constraintRows = [];

      workbook.xlsx.readFile(filename)
         .then(() => {
            ws.eachRow((row, rowNumber) => {
               // console.log('Row ' + rowNumber + ' = ' + JSON.stringify(row.values));
               if ((rowNumber > prodRowNo) && (rowNumber < lastRowNo)) {
                  records.push(row.values);
               } else if (rowNumber === prodRowNo) {
                  let tempArr = row.values;
                  productNames = tempArr.slice(prodStart, prodLast + 1).map((re) => {
                     return re.replace("\n", "");
                  });
               } else if ((rowNumber > conStrtRow + 1) && (rowNumber < conEndRow)) {
                  constraintRows.push(row.values)
               }
            });
            callBack(null, records, constraintRows, tranTags, pickIndex);
         }).catch((e) => {
            callBack(e)
         })

   }

   // Applying the ruleof1toN and creating extra rows based on its values
   function applyTestMthdlogy(records, constraintRows, tranTags, pickIndex, callBack) {
      let {
         valuesIndx,
         testMthdIndx
      } = tranTags;
      let results = [];
      let recordLen = records.length;
      let ruleOfNVal = [];
      let rcrdCounter = 0;


      for (let i = 0; i < recordLen; i++) {
         let rec = records[i];
         if (hexFlag === true && rec[valuesIndx] !== undefined) {
            let rawValue = rec[valuesIndx].toString();
            let bufferTxt = Buffer.from(rawValue, "utf8");
            let hexVal = bufferTxt.toString("hex");
            rec[valuesIndx] = hexVal;
         }
         for (let j = 1; j < rec.length; j++) {
            if (j === testMthdIndx && rec[j] < 2) {
               results.push(rec)
            } else if (j === testMthdIndx && rec[j] > 1) {
               let iterator = rec[j];
               for (let k = 0; k < iterator; k++) {
                  let temp = [...rec];
                  if (k === 0) {
                     ruleOfNVal.push({
                        key: `${temp[valuesIndx]}`,
                        val: iterator
                     })
                     results.push(temp);
                  } else {
                     temp.splice(valuesIndx, 1, `${temp[valuesIndx]}_[[${k}]]`);
                     results.push(temp);
                  }
               }
            }
         }
         rcrdCounter++;
      }
      if (rcrdCounter === recordLen) {
         let pickedXLData = results.map((res) => _.pullAt(res, pickIndex));
         callBack(null, pickedXLData, constraintRows, ruleOfNVal, tranTags)
      }

   }

   // Applying the Negative Optimization Logic to the pickedXLData
   function applyNegOptimizn(pickedXLData, constraintRows, ruleOfNVal, tranTags, callBack) {
      let optimizedData = [];
      let pickedXLDataLen = pickedXLData.length;
      let optimzDtaCounter = 0;
      for (let x = 0; x < pickedXLDataLen; x++) {
         let tempRow = pickedXLData[x];
         let findNeg = tempRow.map((currentValue, index) => {
            if (currentValue === "✖")
               return index;
         })
         let filterNeg = findNeg.filter((filt) => filt);
         if (filterNeg.length > 0) {
            if ((filterNeg.length === 1) /*&& (tempRow[1].includes("_[[") === false)*/ ) {
               tempRow.push(filterNeg[0])
            } else if ((filterNeg.length > 1) /*&& (tempRow[1].includes("_[[") === false)*/ ) {
               tempRow.push(filterNeg[Math.floor(Math.random() * filterNeg.length)])
            } else {
               tempRow.push(false);
            }
         } else {
            tempRow.push(false)
         }
         optimizedData.push(tempRow);
         optimzDtaCounter++;
      }
      if (optimzDtaCounter === pickedXLDataLen) {
         callBack(null, optimizedData, constraintRows, ruleOfNVal, tranTags)
      }

   }

   // Getting the missed Indexes among constraint dependant attribute values and applying ruleof1toN
   function constraintData(optimizedData, constraintRows, ruleOfNVal, tranTags, callBack) {
      let {
         conProdIndx,
         conAttrIndx,
         conValIndx,
         conDepAttrIndx,
         conOperatorIndx,
         depValStrtIndx,
         depValEndIndx
      } = tranTags;
      let pickConstIndx = [conProdIndx, conAttrIndx, conValIndx, conDepAttrIndx, conOperatorIndx, depValStrtIndx, depValEndIndx]
      let missConstIndx = [];
      for (let i = depValStrtIndx + 1; i < depValEndIndx; i++) {
         missConstIndx.push(i)
      }
      pickConstIndx.splice(6, 0, ...missConstIndx)
      let pickedConstraintData = constraintRows.map((el) => _.pullAt(el, pickConstIndx));
      let replSplChar = pickedConstraintData.map(ele => {
         return ele.map((currVal, index) => {
            let replaceVal = currVal;
            if (index !== 0 && index !== 1 && index !== 3 && index !== 4 && currVal !== undefined && hexFlag === true) {
               let rawValue = currVal.toString();
               let bufferTxt = Buffer.from(rawValue, "utf8");
               let hexVal = bufferTxt.toString("hex");
               replaceVal = hexVal.trim();
            } else if ((index === 1 && currVal !== undefined) || (index === 3 && currVal !== undefined)) {
               replaceVal = currVal.replace(/\n/g, ` `).toLowerCase().trim();
            } else {
               replaceVal = currVal;
            }
            return replaceVal;
         })
      })
      let replSplCharLen = replSplChar.length;
      let ruleOfNValLen = ruleOfNVal.length;
      let finConstraintData = [];
      let prodConstraints = [];
      let constraintCounter = 0;

      //console.log(missConstIndx, " missConstIndx ");
      //console.log(pickConstIndx, " pickConstIndx ");
      //console.log(ruleOfNVal, " ruleOfNVal ")

      for (let i = 0; i < replSplCharLen; i++) {
         let rw = replSplChar[i];
         let optr = rw[4]
         rw[4] = (optr && optr.toLowerCase() === "equal to") ? "=" : "!=";
         prodConstraints.push(rw[0])
         finConstraintData.push(rw)
         for (let j = 0; j < ruleOfNValLen; j++) {
            let iterations = ruleOfNVal[j].val;
            if (rw[2] === ruleOfNVal[j].key) {
               if (iterations < 2) {
                  finConstraintData.push(rw)
               } else {
                  for (let k = 0; k < iterations; k++) {
                     let tempRw = [...rw];
                     if (k === 0) {
                        finConstraintData.push(tempRw);
                     } else {
                        tempRw.splice(2, 1, `${tempRw[2]}_[[${k}]]`);
                        finConstraintData.push(tempRw);
                     }
                  }
               }
            }

         }
         constraintCounter++;
      }
      if (constraintCounter === replSplCharLen) {
         let uniqConstraintData = Array.from(new Set(finConstraintData.map(JSON.stringify)), JSON.parse);
         callBack(null, optimizedData, uniqConstraintData)
      }
   }

   // Writing the XML File for every Product by using the optimizedData
   function writeXML(optimizedData, uniqConstraintData, callBack) {
      const xmlCreation = (productName, prodIndex, productCounter) => {
         async.waterfall([
            // filtering the XL Data for every product
            function filterXLData(innerCallBack) {
               let filteredData = optimizedData.map((res) => {
                  let temp = {};
                  let attrName = res[0] && res[0].replace(/\n/g, ` `).toLowerCase().trim();
                  attrNames.push(attrName);
                  temp.attrName = attrName;
                  temp.attrValue = res[1];
                  //"✖" "✔"
                  if (res[prodIndex] === "✔") {
                     temp.attrType = "Positive"
                  } else if (res[prodIndex] === "✖" && prodIndex === res[res.length - 1]) {
                     temp.attrType = "Negative"
                  }

                  return temp;
               })
               uniqAttr = _.uniq(attrNames);
               let loopData = [];
               let forLoopCounter;
               for (let i = 0; i < uniqAttr.length; i++) {
                  forLoopCounter = i;
                  let tempJson = {}
                  let posArr = [];
                  let negArr = [];
                  for (let key in filteredData) {
                     if (filteredData[key].attrName === uniqAttr[i]) {
                        tempJson["name"] = `_${i}`;
                        tempJson["originalName"] = filteredData[key].attrName;
                        tempJson["index"] = i;
                        if (filteredData[key].attrType === "Positive")
                           posArr.push(filteredData[key].attrValue);
                        else if (filteredData[key].attrType === "Negative")
                           negArr.push(filteredData[key].attrValue);
                     }
                  }
                  if (negArr.length > 0 && posArr.length < 1) {
                     attrNoError = false;
                     errorProducts.push(uniqAttr[i])
                  }
                  tempJson["posArr"] = posArr;
                  tempJson["negArr"] = negArr;
                  loopData.push(tempJson);
                  forLoopCounter++;
               }
               if (forLoopCounter === uniqAttr.length) {
                  let jsonData = {};
                  jsonData.product = productName;
                  jsonData.data = loopData;
                  innerCallBack(null, jsonData)
               }

            },
            // Reading the XML Template
            function readTemplateXML(jsonData, innerCallBack) {
               let attrCount = 0;
               let finalStr;
               fs.readFile(transacTemplate, (err, templateData) => {
                  if (err) {
                     innerCallBack(err);
                  } else {
                     let template;
                     template = templateData.toString();
                     let tempAttribute = [];
                     let tempPositiveAttributeTemplate = [];
                     let tempNegativeAttributeTemplate = [];
                     let attrStrtIndex = template.search("##Attribute-START##");
                     let attrEndIndex = template.search("</Parameters>");
                     let attribute = template.substring(attrStrtIndex, attrEndIndex);
                     let length = jsonData.data.length;
                     for (let i = 0; i < length; i++) {
                        let positiveArr = jsonData.data[i].posArr;
                        let negativeArr = jsonData.data[i].negArr;
                        // console.log(JSON.stringify(jsonData.data[i], null, 2), " JSON  data ")
                        let pos = "";
                        let neg = "";

                        // One Positive value must be there for every attribute
                        if (positiveArr.length > 0) {
                           tempAttribute[i] = attribute;
                           let posStrt = attribute.search("##POSITIVE-START##");
                           let posEnd = attribute.search("</values>");
                           let negStrt = attribute.search("##NEGATIVE-START##");
                           let negEnd = attribute.search("</invalidValues>")
                           tempPositiveAttributeTemplate[i] = tempAttribute[i].substring(posStrt, posEnd);
                           tempNegativeAttributeTemplate[i] = tempAttribute[i].substring(negStrt, negEnd);
                           for (let j = 0; j < positiveArr.length; j++) {
                              pos = pos + tempPositiveAttributeTemplate[i].replace("##POSITIVEVALUE##", positiveArr[j].trim());
                           }
                           for (let k = 0; k < negativeArr.length; k++) {
                              if (`${negativeArr[k]}`.includes("_[[") === false) {
                                 neg = neg + tempNegativeAttributeTemplate[i].replace("##NEGATIVEVALUE##", `[[N]]_${negativeArr[k]}`.trim())
                              }
                           }

                           tempAttribute[i] = tempAttribute[i].replace("##INDEX##", i);
                           tempAttribute[i] = tempAttribute[i].replace("##ATTRIBUTE-NAME##", jsonData.data[i].name)
                           tempAttribute[i] = tempAttribute[i].replace("<value>##POSITIVEVALUE##</value>", pos);
                           tempAttribute[i] = tempAttribute[i].replace("<invalidValue>##NEGATIVEVALUE##</invalidValue>", neg);

                           let str = tempAttribute.toString()
                           let str1 = str.replace(/##Attribute-START##/g, "")
                           let str2 = str1.replace(/##Attribute-END##/g, "")
                           let str3 = str2.replace(/##POSITIVE-START##/g, "")
                           let str4 = str3.replace(/##POSITIVE-END##/g, "")
                           let str5 = str4.replace(/##NEGATIVE-START##/g, "")
                           let str6 = str5.replace(/##NEGATIVE-END##/g, "")
                           let str7 = str6.replace(/,/g, "")
                           finalStr = str7;

                        }
                        attrCount++;
                     }
                     if (attrCount === jsonData.data.length) {
                        let prdNm = productName;
                        if (hexFlag === true) {
                           let bufferTxt = Buffer.from(productName, "utf8");
                           let hexVal = bufferTxt.toString("hex");
                           prdNm = hexVal;
                        }

                        let x = template;
                        let text = x.substring(attrStrtIndex, attrEndIndex);
                        let xmlTxt = x.replace(text, finalStr);
                        xmlTxt = xmlTxt.replace("##PRODUCT-NAME##", prdNm);
                        innerCallBack(null, productName, xmlTxt)
                     }
                  }
               })
            },
            // Replacing Constraints Names to index based on Uniq Attribute Names
            function replaceConstraintNames(productName, xmlTxt, innerCallBack) {
               let len = uniqConstraintData.length;
               let replacedVal = [];
               for (let l = 0; l < len; l++) {
                  let rec = uniqConstraintData[l];
                  let atrVal = uniqAttr.indexOf(rec[1]);
                  let depAtrVal = uniqAttr.indexOf(rec[3]);
                  let temp = [...rec];
                  temp.splice(1, 1, `_${atrVal}`);
                  temp.splice(3, 1, `_${depAtrVal}`);
                  replacedVal.push(temp);
               }
               innerCallBack(null, productName, xmlTxt, replacedVal)
            },
            // Adding Constraints to the XML file if constraint exist
            function writeContraintsToXML(productName, xmlTxt, replacedVal, innerCallBack) {
               let constraintFinalTags = "";
               for (let m = 0; m < replacedVal.length; m++) {
                  let constraintTags = "";
                  let constraintAtrText;
                  let constraintDepText = "";
                  let rcrd = replacedVal[m];
                  let constraintRow = "";
                  let constraintStTag = "";
                  let paramTag = "";
                  let constraintEndTag = "";

                  if (rcrd[0] === productName || rcrd[0] === "All Product") {
                     constraintAtrText = `${rcrd[1]}=&quot;${rcrd[2]}&quot;`
                     let cnTxt1;
                     for (let n = 5; n < rcrd.length; n++) {
                        if (n === 5) {
                           cnTxt1 = `${rcrd[3]}${rcrd[4]}&quot;${rcrd[5]}&quot;`
                        } else if (n !== 5 && rcrd[n] !== null) {
                           constraintDepText += `||${rcrd[3]}${rcrd[4]}&quot;${rcrd[n]}&quot;`
                        }
                        rcrd
                     }
                     constraintDepText = constraintDepText !== undefined ? constraintDepText : ""
                     constraintRow = `(${constraintAtrText})=&gt;(${cnTxt1}${constraintDepText})`;
                     constraintStTag = `<Constraint text="${constraintRow}">`
                     paramTag = `<Parameters><Parameter name="${rcrd[1]}"/><Parameter name="${rcrd[3]}"/></Parameters>`
                     constraintEndTag = `</Constraint>`
                  }
                  constraintTags = `${constraintStTag}${paramTag}${constraintEndTag}`
                  constraintFinalTags += constraintTags;
               }
               let mainConstraintTag = `<Constraints>${constraintFinalTags}`
               let contsraintTxt = xmlTxt.replace("##CONSTRAINT-BLOCK##", mainConstraintTag)
               contsraintTxt = contsraintTxt.replace("<Constraints/>", "");
               innerCallBack(null, contsraintTxt);

            },
            // Writing the XML based on Product
            function writeToXML(xmlText, innerCallBack) {
               let xmlFile = path.join(transMat, sheetName, "XML", `p${productCounter}.xml`)
               if (attrNoError) {
                  fs.writeFile(xmlFile, formatXml(xmlText, {
                     collapseContent: true
                  }), (err) => {
                     if (err) {
                        innerCallBack(err)
                     } else {
                        innerCallBack(null)
                     }
                  })
               } else {
                  innerCallBack(null)
               }

            }
         ], (innerErr) => {
            if (innerErr) {
               // console.log(innerErr, " inner async callback error block ")
               callBack(innerErr)
            } else {
               productCounter++;
               callXMLCrtion(productCounter)
            }
         })
      }
      const callXMLCrtion = (productCounter) => {
         if (productCounter < productNames.length) {
            let prodIndex = productCounter + 3;
            xmlCreation(productNames[productCounter], prodIndex, productCounter)
         } else {
            callBack(null)
         }

      }
      callXMLCrtion(0);
   }


   // Creating the Products JSON
   function crtProductFlName(callBack) {
      let prodFile = path.join(transMat, sheetName, "tMtrxProdName.json")
      if (attrNoError) {
         fs.writeFile(prodFile, JSON.stringify(productNames, null, 2), (err) => {
            if (err)
               callBack(err)
            else {
               // console.log("Unique Product Values Written to the Product file");
               callBack(null)
            }
         })

      } else {
         callBack(null)
      }

   }

   // Creating the Attributes JSON
   function crtAttrbtFlName(callBack) {
      let attrFile = path.join(transMat, sheetName, "tMtrxUniqueAttr.json");
      if (attrNoError) {
         fs.writeFile(attrFile, JSON.stringify(uniqAttr, null, 2), (err) => {
            if (err)
               callBack(err)
            else {
               // console.log("Unique Attribute Values Written to the Attribute file");
               callBack(null)
            }
         })
      } else {
         callBack(null)
      }
   }
}