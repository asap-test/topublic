Test Basis Engine (Node.js,MongoDB)

APILOGICS:
#All the API Logics will be inside this folder.

CONFIG:
#All the cofiguration details will be inside this folder

INTERFACE MATRIX:
#All the core logic for interface matrix genaration will be inside this folder

TRANSACTION MATRIX:
#All the core logic for transaction matrix genaration will be inside this folder

MIDDLEWARE:
#It is for applying some logic for every route

index.js(Main Server File - Entry Point)
#Database connection will be established from this file
#Routes will imported from apilogics folder and used as endpoints
