const http = require("http");
const express = require("express");
const app = express();
const fs = require("fs");
const path = require("path");
const port = 4010;

let absPath = "../"
let sourcePath = path.join(absPath,"SOURCE")
let runPath = path.join(absPath,"_RUNS")
let folders = [sourcePath, runPath]
try {
   folders.map((el) => {
      if (fs.existsSync(el)) {
         // console.log(`${el} directory exists.`)
      } else {
         fs.mkdirSync(el);
         // console.log(`${el} directory does not exist.`)
      }
   })
} catch (e) {
   console.log("An error occurred in directory creation.")
}


// Starting Server
const server = http.createServer(app);
server.listen(port, function (err) {
   if (err) console.log(`App Server err ${err}`);
   else {
      console.log(`Server started in ${port}`);
      let absPath = "../";
      let changeEve = false;
      let watchPath = path.join(absPath,"SOURCE")
      let matrix = require("./apilogics/apimatrix")
      matrix.run()
      // fs.watch(watchPath, (eventType, filename) => {
      //    console.log("\nThe file", filename, "was modified!");
      //    console.log("The type of change was:", eventType);
      //    if(eventType === "change"){
      //       changeEve = true;
           
      //    }
      //  });
   }
});