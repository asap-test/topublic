const Excel = require("exceljs");
const async = require("async");
const path = require("path");
const fs = require("fs");
const fse = require("fs-extra");
const _ = require("lodash");
const formatXml = require("xml-formatter");
const intrFcTemplate = path.join("utils", "inter_matrix_template.xml")


// Creating XML for ACT Tool using the data from XL file
exports.crtXML = (paths, sheetName, errTxt, hexFlag) => {
   let {
      results,
      sourcePath,
      interfaceMat,
   } = paths;
   const workbook = new Excel.Workbook();
   let noError = true;
   return new Promise((resolve, reject) => {
      async.waterfall([
         copyXL,
         getRowNos,
         getRawXLData,
         appendTranName,
         constraintData,
         prepareJSON,
         writeXML,
         crtIntrFcNmJSON
      ], (err) => {
         if (err) {
            noError = false ? resolve(false) : reject(err)
         } else {
            resolve(true)
         }
      })
   })

   // Creating the copy of the Source XL File
   function copyXL(callBack) {
      let filename;
      if (fs.existsSync(sourcePath)) {
         if (fs.existsSync(results)) {
            let src = path.join(sourcePath, "source.xlsx");
            filename = path.join(results, `results.xlsx`);
            try {
               if (!fs.existsSync(filename)) {
                  fse.copySync(src, filename)
               }
               callBack(null, filename)
            } catch (err) {
               callBack(new Error("Error in copying the source file"))
            }
         } else {
            callBack(new Error("Error in copying the source file"))
         }
      } else {
         callBack(new Error("Source Path Doesn't Exist"))
      }
   }

   // Getting the Row Numbers , interFace Start Index &  interFace End Index based on tags
   function getRowNos(filename, callBack) {
      let intrFcTags = {};
      workbook.xlsx.readFile(filename)
         .then(() => {
            let ws = workbook.getWorksheet(sheetName);
            ws.eachRow((row, rowNumber) => {
               row.eachCell((cell) => {
                  if (cell.value === "#intr-strt") {
                     intrFcTags.firstRowNo = rowNumber;
                     intrFcTags.actualRowCount = ws.actualRowCount;
                     intrFcTags.actualColumnCount = ws.actualColumnCount;
                     intrFcTags.intrStrtIndx = row.values.indexOf("#intr-strt");
                  } else if (cell.value === "Interface") {
                     intrFcTags.interIndx = row.values.indexOf("Interface");
                     intrFcTags.prodRowNo = rowNumber;
                  } else if (cell.value === "InterfaceID") {
                     intrFcTags.codeIndx = row.values.indexOf("InterfaceID");
                  } else if (cell.value === "Source") {
                     intrFcTags.srcIndx = row.values.indexOf("Source");
                  } else if (cell.value === "Destination") {
                     intrFcTags.destIndx = row.values.indexOf("Destination");
                  } else if (cell.value === "Mode") {
                     intrFcTags.modeIndx = row.values.indexOf("Mode");
                  } else if (cell.value === "Middleware") {
                     intrFcTags.middlIndx = row.values.indexOf("Middleware");
                  } else if (cell.value === "Transactions") {
                     intrFcTags.tranIndx = row.values.indexOf("Transactions");
                  } else if (cell.value === "#intr-atr-strt") {
                     intrFcTags.intrAtrStrtIndx = row.values.indexOf("#intr-atr-strt")
                  } else if (cell.value === "#intr-atr-end") {
                     intrFcTags.intrAtrEndIndx = row.values.indexOf("#intr-atr-end")
                  } else if (cell.value === "#intr-end") {
                     intrFcTags.lastRowNo = rowNumber;
                  } else if (cell.value === "#constraint-identifier") {
                     intrFcTags.conStrtRow = rowNumber;
                     intrFcTags.conIdentifier = row.values.indexOf("#constraint-identifier");
                     intrFcTags.conProdIndx = row.values.indexOf("#constraint-product-start");
                     intrFcTags.conAttrIndx = row.values.indexOf("#constraint-attr");
                     intrFcTags.conValIndx = row.values.indexOf("#constraint-value");
                     intrFcTags.conDepAttrIndx = row.values.indexOf("#dep-atr");
                     intrFcTags.conOperatorIndx = row.values.indexOf("#operator");
                     intrFcTags.depValStrtIndx = row.values.indexOf("#dep-val-start");
                     intrFcTags.depValEndIndx = row.values.indexOf("#dep-val-end");
                  } else if (cell.value === "#constraint-product-end") {
                     intrFcTags.conEndRow = rowNumber;
                  }
               })
            })
            callBack(null, intrFcTags, filename, ws);
         })
         .catch((error) => {
            callBack(error)
         })
   }

   // Getting the Raw XL Data from the copied XL File
   function getRawXLData(intrFcTags, filename, ws, callBack) {
      let {
         prodRowNo,
         lastRowNo,
         conStrtRow,
         conEndRow
      } = intrFcTags;
      let records = [];
      let attrIndx = [];
      let constraintRows = [];
      workbook.xlsx.readFile(filename)
         .then(() => {
            ws.eachRow((row, rowNumber) => {
               if ((rowNumber === prodRowNo) && (rowNumber < lastRowNo)) {
                  row.values.map((curVal, index) => {
                     if (curVal === "Attributes") {
                        attrIndx.push(index)
                     }
                  });
               } else if ((rowNumber > prodRowNo) && (rowNumber < lastRowNo)) {
                  records.push(row.values);
               } else if ((rowNumber > conStrtRow + 1) && (rowNumber < conEndRow)) {
                  constraintRows.push(row.values)
               }
            });
            // console.log(intrFcTags, " intrFcTags  ")
            // console.log(records, " records ");
            // console.log(constraintRows, " constraintRows ")
            intrFcTags.attrIndx = attrIndx;
            callBack(null, records, constraintRows, intrFcTags);
         })
         .catch((e) => {
            callBack(e)
         })
   }

   // Appending Transaction to the interface Names
   function appendTranName(records, constraintRows, intrFcTags, callBack) {
      let {
         interIndx,
         codeIndx
      } = intrFcTags;
      let intrFcNames = records.map((rcrd) => {
         let str1 = ``;
         let str2 = ``;
         let intrFcNm = rcrd[interIndx] && Buffer.from(rcrd[interIndx].toString(), "utf8").toString("hex").trim();
         str1 = intrFcNm;
         let code = rcrd[codeIndx] && Buffer.from(rcrd[codeIndx].toString(), "utf8").toString("hex").trim();
         str2 = code;
         return `${str1}__[[${str2}]]`;
      })
      // console.log(intrFcNames, " intrFcNames ")
      callBack(null, intrFcNames, records, constraintRows, intrFcTags)
   }

   // Getting the missed Indexes among constraint dependant attribute values
   function constraintData(intrFcNames, records, constraintRows, intrFcTags, callBack) {
      let {
         conIdentifier,
         conProdIndx,
         conAttrIndx,
         conValIndx,
         conDepAttrIndx,
         conOperatorIndx,
         depValStrtIndx,
         depValEndIndx
      } = intrFcTags;
      let pickConstIndx = [conIdentifier, conProdIndx, conAttrIndx, conValIndx, conDepAttrIndx, conOperatorIndx, depValStrtIndx, depValEndIndx]
      let missConstIndx = [];
      for (let i = depValStrtIndx + 1; i < depValEndIndx; i++) {
         missConstIndx.push(i)
      }
      pickConstIndx.splice(7, 0, ...missConstIndx);
      let tempRws = constraintRows.map((el) => _.pullAt(el, pickConstIndx));
      let cnstRws = tempRws.map(ele => {
         return ele.map((currVal, index) => {
            let replaceVal = currVal;
            if (index !== 2 && index !== 4 && index !== 5 && currVal !== undefined) {
               let bufferTxt = currVal && Buffer.from(currVal.toString(), "utf8");
               if (currVal === 0) {
                  bufferTxt = currVal.toString();
               }
               let hexVal = bufferTxt.toString("hex").trim();
               replaceVal = hexVal.trim();
            } else if ((index === 2 && currVal !== undefined) || (index === 4 && currVal !== undefined)) {
               // replaceVal = currVal.replace(/\n/g, ` `).toLowerCase().trim();
               let bufferTxt = currVal && Buffer.from(currVal.toString(), "utf8");
               let hexVal = bufferTxt.toString("hex").trim();
               replaceVal = `_${hexVal}`;
            }
            return replaceVal;
         })
      })
      // console.log(pickConstIndx, " pickConstIndx ");
      // console.log(missConstIndx, " missConstIndx ");
      // console.log(cnstRws, " cnstRows ")
      let cnstRwsLen = cnstRws.length;
      let finCnstRws = [];
      let constraintCounter = 0;
      for (let i = 0; i < cnstRwsLen; i++) {
         let rw = cnstRws[i];
         let optr = rw[5]
         rw[5] = (optr && optr.toLowerCase() === "equal to") ? "=" : "!=";
         finCnstRws.push(rw)
         constraintCounter++;
      }
      if (constraintCounter === finCnstRws.length) {
         callBack(null, intrFcNames, records, finCnstRws, intrFcTags)
      }
   }

   // Prepare JSON Data for XML Creation
   function prepareJSON(intrFcNames, records, finCnstRws, intrFcTags, callBack) {
      let {
         srcIndx,
         codeIndx,
         destIndx,
         modeIndx,
         middlIndx,
         tranIndx,
         intrAtrEndIndx,
         attrIndx
      } = intrFcTags;

      attrIndx.push(intrAtrEndIndx)
      let attrIndxPairs = attrIndx.reduce(function (result, value, index, array) {
         if (index % 1 === 0)
            result.push(array.slice(index, index + 2));
         return result;
      }, []);

      // let missArrVal = [];
      // for (let m = intrAtrStrtIndx; m <= intrAtrEndIndx; m++) {
      //     missArrVal.push(m)
      // }
      // let sortedArr = missArrVal.sort((a, b) => a - b);

      let counter = 0;
      let rcrdsLen = records.length;
      let jsonData = records.map((rcrd, index) => {
         let intrFcNm = intrFcNames[index].split("__")[0];
         let temp = {};
         temp["Interface"] = intrFcNm;
         temp["Id"] = rcrd[codeIndx]
         temp["Source"] = rcrd[srcIndx];
         temp["Destination"] = rcrd[destIndx];
         temp["Mode"] = rcrd[modeIndx];
         temp["Middleware"] = rcrd[middlIndx];
         temp["Transactions"] = rcrd[tranIndx];
         temp["attributes"] = [];

         let atrArLen = attrIndx.length;
         let atrKey;
         for (let at = 0; at < atrArLen - 1; at++) {
            let atrCount = at;
            if (rcrd[attrIndx[at]] !== undefined) {
               atrKey = rcrd[attrIndx[at]]
               let tmpArr = [];
               let slicedRow;
               let [x, y] = attrIndxPairs[at];
               if (atrCount === attrIndxPairs.length - 2)
                  slicedRow = rcrd.slice(x + 1);
               else
                  slicedRow = rcrd.slice(x + 1, y)
               //console.log(slicedRow, " slicedRow ")
               for (let j = 0; j < slicedRow.length; j++) {
                  if (slicedRow[j] !== undefined && slicedRow[j].toString().length > 0)
                     tmpArr.push(slicedRow[j])
               }
               temp["attributes"].push({
                  name: atrKey,
                  values: [...tmpArr]
               });
               atrCount++;

            }
         }
         counter++;
         return temp;

      });
      // console.log(attrIndx, " attrIndx ");
      // console.log(JSON.stringify(jsonData, null, 2), " jsonData  ");
      if (counter === rcrdsLen) {
         callBack(null, intrFcNames, jsonData, finCnstRws)
      }
   }

   // Writing XML File
   function writeXML(intrFcNames, jsonData, finCnstRws, callBack) {
      let jsnDataLen = jsonData.length;
      const XMLCreation = (counter, intrFcArr) => {
         async.waterfall([
            // Reading the XML Template
            function readTemplateXML(cb) {
               fs.readFile(intrFcTemplate, (err, templateData) => {
                  if (err) {
                     cb(err);
                  } else {
                     let intrFcNm = intrFcArr.Interface;
                     let codeNm = intrFcArr.Id && Buffer.from(intrFcArr.Id.toString(), "utf8").toString("hex").trim();
                     let fileName = `p${counter}`;
                     let attrArr = intrFcArr.attributes;
                     let intrFcKeys = Object.keys(intrFcArr);
                     let template = templateData.toString();
                     let tempParamAttr = [];
                     let tempAttrVal = [];
                     let attrStrtIndex = template.search("##Attribute-START##");
                     let attrEndIndex = template.search("</Parameters>");
                     let attribute = template.substring(attrStrtIndex, attrEndIndex);
                     let str = "";
                     for (let i = 0; i < intrFcKeys.length - 1; i++) {
                        let replaceVal = intrFcArr[intrFcKeys[i]];
                        if (i !== 0 && i !== 1) {
                           replaceVal = intrFcArr[intrFcKeys[i]] && Buffer.from(intrFcArr[intrFcKeys[i]].toString(), "utf8").toString("hex")
                        } else if (i === 0) {
                           replaceVal = intrFcNm
                        } else if (i === 1) {
                           replaceVal = codeNm
                        }
                        tempParamAttr[i] = attribute;
                        let parStrt = attribute.search("##Attribute-START##");
                        let parEnd = attribute.search("##Attribute-END##");
                        tempParamAttr[i] = tempParamAttr[i].substring(parStrt, parEnd);
                        tempParamAttr[i] = tempParamAttr[i].replace("##INDEX##", i)
                        tempParamAttr[i] = tempParamAttr[i].replace("##ATTRIBUTE-NAME##", `_${Buffer.from([intrFcKeys[i]].toString(), "utf8").toString("hex")}`)
                        tempParamAttr[i] = tempParamAttr[i].replace("##VALUE##", replaceVal)
                        str += tempParamAttr[i]
                     }

                     for (let j = 0; j < attrArr.length; j++) {
                        let param = "";
                        tempParamAttr[j] = attribute;
                        let i = intrFcKeys.length - 1 + j;
                        let parStrt = attribute.search("##Attribute-START##");
                        let parEnd = attribute.search("##Attribute-END##");
                        let atrStrt = attribute.search("##Parameter-START##");
                        let atrEnd = attribute.search("</values>");
                        let attrNm = `_${Buffer.from(attrArr[j].name.toString().trim(), "utf8").toString("hex")}`
                        tempAttrVal[j] = tempParamAttr[j].substring(atrStrt, atrEnd);
                        tempParamAttr[j] = tempParamAttr[j].substring(parStrt, parEnd);
                        tempParamAttr[j] = tempParamAttr[j].replace("##INDEX##", i)
                        tempParamAttr[j] = tempParamAttr[j].replace("##ATTRIBUTE-NAME##", attrNm)
                        let values = attrArr[j].values;
                        if (attrArr.length > 1) {
                           values.push("NA")
                        }
                        let uniqValues = _.uniq(values)
                        for (let k = 0; k < uniqValues.length; k++) {
                           let uniqVal;
                           let val = uniqValues[k]
                           let bufferTxt = Buffer.from(val.toString(), "utf8");
                           let hexVal = bufferTxt.toString("hex");
                           uniqVal = hexVal.trim();
                           param += tempAttrVal[j].replace("##VALUE##", uniqVal)
                        }
                        tempParamAttr[j] = tempParamAttr[j].replace("<value>##VALUE##</value>", param)
                        str += tempParamAttr[j]
                     }
                     str = str.toString();
                     let str1 = str.replace(/##Parameter-START##/g, "")
                     let str2 = str1.replace(/##Parameter-END##/g, "")
                     let finalStr = str2.replace(/##Attribute-START##/g, "")
                     let x = template;
                     let xmlTxt = x.substring(attrStrtIndex, attrEndIndex);
                     xmlTxt = x.replace(xmlTxt, finalStr);
                     cb(null, xmlTxt, finCnstRws, fileName, intrFcNm, codeNm)

                  }
               })
            },
            // Replacing Constraints Names with spaces
            function replaceConstraintNames(xmlTxt, finCnstRws, fileName, intrFcNm, codeNm, cb) {
               let len = finCnstRws.length;
               let replacedVal = [];
               for (let l = 0; l < len; l++) {
                  let rec = finCnstRws[l];
                  let atrKey = rec[2].trim().replace(/ /g, "__");
                  let depAtrKey = rec[4].trim().replace(/ /g, "__");
                  let temp = [...rec];
                  temp.splice(2, 1, `${atrKey}`);
                  temp.splice(4, 1, `${depAtrKey}`);
                  replacedVal.push(temp);
               }
               cb(null, fileName, intrFcNm, codeNm, xmlTxt, replacedVal)
            },
            // Adding Constraints to the XML file if constraint exist
            function writeContraintsToXML(fileName, intrFcNm, codeNm, xmlTxt, replacedVal, cb) {
               let constraintFinalTags = "";
               for (let m = 0; m < replacedVal.length; m++) {
                  let constraintTags = "";
                  let constraintAtrText;
                  let constraintDepText = "";
                  let rcrd = replacedVal[m];
                  let constraintRow = "";
                  let constraintStTag = "";
                  let paramTag = "";
                  let constraintEndTag = "";
                  if (rcrd[0] === codeNm && rcrd[1] === intrFcNm) {
                     constraintAtrText = `${rcrd[2]}=&quot;${rcrd[3]}&quot;`
                     let cnTxt1;
                     for (let n = 6; n < rcrd.length; n++) {
                        if (n === 6) {
                           cnTxt1 = `${rcrd[4]}${rcrd[5]}&quot;${rcrd[6]}&quot;`
                        } else if (n !== 5 && rcrd[n] !== null && rcrd[n] !== undefined) {
                           constraintDepText += `||${rcrd[4]}${rcrd[5]}&quot;${rcrd[n]}&quot;`
                        }
                     }
                     constraintDepText = constraintDepText !== undefined ? constraintDepText : ""
                     constraintRow = `(${constraintAtrText})=&gt;(${cnTxt1}${constraintDepText})`;
                     constraintStTag = `<Constraint text="${constraintRow}">`
                     paramTag = `<Parameters><Parameter name="${rcrd[2]}"/><Parameter name="${rcrd[4]}"/></Parameters>`
                     constraintEndTag = `</Constraint>`
                  }
                  constraintTags = `${constraintStTag}${paramTag}${constraintEndTag}`
                  constraintFinalTags += constraintTags;
               }
               let mainConstraintTag = `<Constraints>${constraintFinalTags}`
               let contsraintTxt = xmlTxt.replace("##CONSTRAINT-BLOCK##", mainConstraintTag)
               contsraintTxt = contsraintTxt.replace("<Constraints/>", "");
               cb(null, fileName, contsraintTxt);

            },
            // Writing the XML based on Interface
            function writeXML(fileName, xmlTxt, cb) {
               let xmlFile = path.join(interfaceMat, sheetName, "XML", `${fileName}.xml`);
               fs.writeFile(xmlFile, formatXml(xmlTxt, {
                  collapseContent: true
               }), (err) => {
                  if (err) {
                     cb(err)
                  } else {
                     cb(null)
                  }
               })

            },
         ], (err) => {
            if (err)
               callBack(err)
            else {
               counter++;
               callXMLCrtion(counter)
            }
         })

      }

      const callXMLCrtion = (count) => {
         if (count < jsnDataLen) {
            // let intrFcFileNm = intrFcNames[count];
            let intrFcArr = jsonData[count];
            XMLCreation(count, intrFcArr)
         } else {
            callBack(null, intrFcNames)
         }
      }
      callXMLCrtion(0)

   }


   // Creating the Interface Names with Transaction JSON
   function crtIntrFcNmJSON(intrFcNames, callBack) {
      let prodFile = path.join(interfaceMat, sheetName, "iMtrx_intrFcName.json")
      fs.writeFile(prodFile, JSON.stringify(intrFcNames, null, 2), (err) => {
         if (err)
            callBack(err)
         else {
            // console.log("Unique Interface-Transaction Names Written to the Interface Names file");
            callBack(null)
         }
      })
   }

}