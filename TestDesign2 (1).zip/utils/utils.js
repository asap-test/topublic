const fs = require("fs");
const path = require("path");
const PDFDocument = require("pdfkit");

// function to create the error pdf
exports.crtPdf = (errTxt, errFile) => {
   return new Promise((resolve, reject) => {
      try {
         const doc = new PDFDocument();
         doc.pipe(fs.createWriteStream(errFile));
         doc
            .font('Times-Roman')
            .fontSize(20)
            .text(errTxt, 100, 100)
            // .rect(doc.x, 0, 450, doc.y).stroke()
            .end();
         resolve(true);
      } catch (e) {
         console.log(e, " e  ")
         reject(false);
      }
   })
}