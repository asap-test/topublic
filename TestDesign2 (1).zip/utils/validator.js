const Excel = require("exceljs");
const async = require("async");
const path = require("path");
const fs = require("fs");
const tags = require("../config/tags").tags;


// Validation function to check the transaction sheet
exports.validTrnSheet = (paths, sheetName, errTxt) => {
   let {
      sourcePath
   } = paths;
   let transTags = tags.transTags;
   let cnstrntTags = tags.cnstrntTags;
   let rcrds = [];
   let constraint = [];
   let errorVal = [];
   return new Promise((resolve, reject) => {
      async.waterfall([
         checkTransTags,
         findMissedTags
      ], (err, bool) => {
         if (err) {
            reject(err)
         } else {
            resolve(bool)
         }
      })
   })


   // function to check transaction tags in the transaction sheet
   function checkTransTags(callBack) {
      if (fs.existsSync(sourcePath)) {
         let filename = path.join(sourcePath, "source.xlsx");
         let workbook = new Excel.Workbook();
         workbook.xlsx.readFile(filename)
            .then(() => {
               let ws = workbook.getWorksheet(sheetName);
               ws.eachRow((row) => {
                  row.eachCell((cell) => {
                     if (cell.value === "#at-start") {
                        let rowValues = Object.values(row.values);
                        rcrds.push(...rowValues);
                     } else if (cell.value === "Test Methodology") {
                        let rw = Object.values(row.values);
                        rcrds.push(...rw);
                     } else if (cell.value === "#at-end") {
                        let rowVl = Object.values(row.values);
                        rcrds.push(...rowVl);
                     } else if (cell.value === "#constraint-product-start") {
                        let vl = Object.values(row.values);
                        constraint.push(...vl);
                     } else if (cell.value === "#constraint-product-end") {
                        let val = Object.values(row.values);
                        constraint.push(...val);
                     } else if (cell.value === "#txn-start") {
                        let rwVl = Object.values(row.values);
                        rcrds.push(...rwVl);
                     }
                  });

               });
               callBack(null)
            }).catch((e) => {
               callBack(e)
            })
      } else {
         callBack(new Error("Source Path Doesn't Exist"))
      }
   }


   // function to find the missed tags in the transaction sheet
   function findMissedTags(callBack) {
      let rcrdVal = [...rcrds];
      transTags.map((currTag) => {
         rcrdVal.includes(currTag) ? errorVal : errorVal.push(currTag)
      })

      cnstrntTags.map((currConTag) => {
         constraint.includes(currConTag) ? errorVal : errorVal.push(currConTag)
      })

      // console.log(errorVal, "Error val")
      if (errorVal.length < 1) {
         callBack(null, true)
      } else {
         let errTags = ``;
         errorVal.map((val, index) => {
            errTags += `${index+1})${val}\n`
         });
         let errText = `The following #tags or keywords are either missing or incorrect in the ${sheetName} in the Excel workbook. Please correct the file and upload again.\n${errTags}\n`;
         errTxt.push(errText);
         callBack(null, false);
      }
   }

}

// Validation function to check the interface sheet
exports.validIntrFcSheet = (paths, sheetName, errTxt) => {
   let {
      sourcePath
   } = paths;
   let intrFcTags = tags.intrFcTags;
   let cnstrntTags = tags.icnstrntTags;
   let intrFcCol = tags.intrFcCol;
   let rcrds = [];
   let constraint = [];
   let colmns = [];
   let errorVal = [];
   return new Promise((resolve, reject) => {
      async.waterfall([
         checkTags,
         findMissedTags
      ], (err, bool) => {
         if (err) {
            reject(err)
         } else {
            resolve(bool)
         }
      })
   })


   // function to check interface tags in the interface sheet
   function checkTags(callBack) {
      if (fs.existsSync(sourcePath)) {
         let filename = path.join(sourcePath, "source.xlsx");
         let workbook = new Excel.Workbook();
         try {
            workbook.xlsx.readFile(filename)
               .then(() => {
                  let ws = workbook.getWorksheet(sheetName);
                  ws.eachRow((row) => {
                     row.eachCell((cell) => {
                        if (cell.value === "#intr-strt") {
                           let rowValues = Object.values(row.values);
                           rcrds.push(...rowValues);
                        } else if (cell.value === "Interface") {
                           let vl = Object.values(row.values);
                           colmns.push(...vl);
                        } else if (cell.value === "#intr-end") {
                           let rwVl = Object.values(row.values);
                           rcrds.push(...rwVl);
                        } else if (cell.value === "#constraint-identifier") {
                           let val = Object.values(row.values);
                           constraint.push(...val);
                        } else if (cell.value === "#constraint-product-end") {
                           let value = Object.values(row.values);
                           constraint.push(...value);
                        }
                     });

                  });
                  callBack(null)
               })
         } catch (e) {
            callBack(e)
         }
      } else {
         callBack(new Error("Source Path Doesn't Exist"))
      }
   }

   // function to find the missed tags in the interface sheet
   function findMissedTags(callBack) {
      let rcrdVal = [...rcrds];
      let columns = [...colmns];
      intrFcTags.map((currTag) => {
         rcrdVal.includes(currTag) ? errorVal : errorVal.push(currTag)
      })
      intrFcCol.map((curTag) => {
         columns.includes(curTag) ? errorVal : errorVal.push(curTag)
      })

      cnstrntTags.map((currConTag) => {
         constraint.includes(currConTag) ? errorVal : errorVal.push(currConTag)
      })
      if (errorVal.length < 1) {
         callBack(null, true)
      } else {
         let errTags = ``;
         errorVal.map((val, index) => {
            errTags += `${index+1})${val}\n`
         });
         let errText = `The following #tags or keywords are either missing or incorrect in the ${sheetName} in the Excel workbook. Please correct the file and upload again.\n${errTags}\n`;
         errTxt.push(errText);
         callBack(null, false);
      }
   }

}